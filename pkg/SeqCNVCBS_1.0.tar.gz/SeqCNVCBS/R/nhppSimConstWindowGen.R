nhppSimConstWindowGen <-
function(controlRates, filename, chromosomeN, nSpike=25, cptLen=seq(2, 40, by=5), nRepeat=2, minGain=1.5, maxGain=4, minLoss=0.01, maxLoss=0.5, pGain=0.6) {
	nCptLen = length(cptLen)
	for(i in 1:nCptLen) {
		normalDataName = sapply(1:nRepeat, function(j) {return(paste(filename, "_Data_Normal_", j, ".txt", sep=""))})
		tumorDataName = sapply(1:nRepeat, function(j) {return(paste(filename, "_Data_Tumor_Spike", cptLen[i], "_", j, ".txt", sep=""))})
		dataFileName = c(normalDataName, tumorDataName)
		sampleName = c(rep(paste(filename, "_N", sep=""), nRepeat), sapply(1:nRepeat, function(j) {return(paste(filename, "_T", cptLen[i], sep=""))}))
		sampleType = c(rep("Normal", nRepeat), rep("Tumor", nRepeat))
		metaMat = cbind(dataFileName, sampleName, sampleType)
		metaName = paste(filename, "_Meta_", cptLen[i], ".txt", sep="")
		colnames(metaMat) = c("File", "Sample", "Type")
		write.table(metaMat, file=metaName, sep="\t", row.names=FALSE, col.names=TRUE, quote=FALSE)
	}
	for(j in 1:nRepeat) {
		dataFileName = paste(filename, "_Data_Normal_", j, ".txt", sep="")
		controlSim = nhppSimulate(controlRates)
		nLength = length(controlSim)
		strandSim = sample(0:1, nLength, replace=TRUE)
		chromosomeSim = rep(chromosomeN, nLength)
		dataMat = cbind(chromosomeSim, controlSim, strandSim)
		write.table(dataMat, file=dataFileName, sep="\t", row.names=FALSE, col.names=FALSE, quote=FALSE)
	}
	for(i in 1:nCptLen) {
		newSpikeRate = nhppSpikeConstWindow(controlRates, nSpike, cptLen[i], minGain, maxGain, minLoss, maxLoss, pGain)
		newSpikeMat = newSpikeRate$spikeMat
		spikeName = paste(filename, "_spikeMat_", cptLen[i], ".txt", sep="")
		write.table(newSpikeMat, file=spikeName, sep="\t", row.names=FALSE, col.names=FALSE, quote=FALSE)
		for(j in 1:nRepeat) {
			dataFileName = paste(filename, "_Data_Tumor_Spike", cptLen[i], "_", j, ".txt", sep="")
			caseSim = nhppSimulate(newSpikeRate$caseRates)
			nLength = length(caseSim)
			strandSim = sample(0:1, nLength, replace=TRUE)
			chromosomeSim = rep(chromosomeN, nLength)
			dataMat = cbind(chromosomeSim, caseSim, strandSim)
			write.table(dataMat, file=dataFileName, sep="\t", row.names=FALSE, col.names=FALSE, quote=FALSE)
			#newSpikeCBSN5 = ScanCBS(controlSim, newSpikeSim, statistic="normal", takeN=5, minStat=8, maxNCut=50, timing=TRUE)
			#newCBSRes = list(spikeCBSN5=newSpikeCBSN5, spikeMat=newSpikeRate$spikeMat)
			#simCBSRes[[counter]] = newCBSRes
		}
	}
}

