.First.lib <- function(lib,pkg) {
   		library.dynam("SeqCNVCBS",pkg,lib)
   		cat("roots 0.1-1 loaded\n")
	}
